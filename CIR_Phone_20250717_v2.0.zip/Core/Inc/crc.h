#ifndef __CRC_H__
#define __CRC_H__
#include "main.h"
uint16_t my_crc(unsigned char *buf, int len);

#endif
