#ifndef __RS485_H__
#define __RS485_H__

#include "main.h"

#define BUF_SIZE 32
#define REG_SIZE    10

typedef struct {
    uint8_t rx_buf[BUF_SIZE];
    uint8_t tx_buf[BUF_SIZE];
    uint8_t rx_len;
    uint8_t tx_len;
    uint8_t frame_len;
} RS485_MSG;

typedef enum {
    RS485_HEAD = 0,
    RS485_ADDR,
    RS485_LEN,
    RS485_DATA,
    RS485_END
} RS485_State;

typedef struct
{
    uint16_t HoldRegAddr;       //地址    
    uint16_t HoldRegData;       //数据
    uint8_t safeLevel;         //读写权限
}HOLDREG;

void RS485_Process(void);
void RS485_Send(uint8_t *data, uint8_t len);
void RS485_Data_Copy(void);

#endif
