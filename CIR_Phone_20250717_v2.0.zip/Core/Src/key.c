#include "key.h"
#include "main.h"
#include "rs485.h"
#include <stdbool.h>
#include "FreeRTOS.h"
#include "task.h"

#define PRESS_KEY(fn)       do { fn(0); HAL_Delay(DELAY_TIME); \
                                 fn(1); HAL_Delay(DELAY_TIME); } while(0)  // 封装按键处理宏

#define DELAY_TIME          500U    //延时继电器开关 ms
#define DIALING_MAP_SIZE    (sizeof(dialing_map)) / sizeof(dialing_map[0]) //按键映射表数量
#define Reg_Len             rs485_msg.rx_buf[2] - 1
#define DIALING_CMD_LEN     0x05U                       /* 拨号指令的长度字段值 */

uint8_t MT_Flag;
uint8_t key_value = 0;
uint8_t last_key_value = 0;

uint8_t Last_reed_value;
uint8_t Reed_value;

extern HOLDREG Reg[];
extern RS485_MSG rs485_msg;
extern volatile uint8_t g_hangup_request;
typedef void (*KeyFunc)(uint8_t);

// 映射表结构
typedef struct {
    uint16_t code;
    KeyFunc  key_func;
} DialingMap;

// 映射表
DialingMap dialing_map[] = {
    {0x60, KEY_0},
    {0x61, KEY_1},
    {0x62, KEY_2},
    {0x63, KEY_3},
    {0x64, KEY_4},
    {0x65, KEY_5},
    {0x66, KEY_6},
    {0x67, KEY_7},
    {0x68, KEY_8},
    {0x69, KEY_9},
    {0x6A, KEY_STAR},
    {0x6E, KEY_POUND},
    {0xDC, KEY_MT},
    {0x6B, KEY_GD}     //挂断
};

void Cir_Dialing(void)
{
    RS485_Process();

    if((g_hangup_request && Led_Mt_flag()) ||
       (Reed_value == REED_SWITCH_OFF && Led_Mt_flag()))
    {
        PRESS_KEY(KEY_GD);
        Reg[Reg_Len].HoldRegData = 0;
        g_hangup_request = 0;
        return;
    }

    if(Reg[Reg_Len].HoldRegData == 0xDC && (!Led_Mt_flag()))
    {
        PRESS_KEY(KEY_MT);
        g_hangup_request = 0;   /* 摘机时清除残留标志 */

        for (uint8_t i = 0; i < Reg_Len; i++)
        {
            if((g_hangup_request && Led_Mt_flag()) ||
               (Reed_Switch_Value() == REED_SWITCH_OFF && Led_Mt_flag()))
            {
                PRESS_KEY(KEY_GD);
                g_hangup_request = 0;
                break;
            }

            uint8_t matched = 0;
            for (uint8_t j = 0; j < DIALING_MAP_SIZE; j++)
            {
                if (Reg[i].HoldRegData == dialing_map[j].code)
                {
                    PRESS_KEY(dialing_map[j].key_func);
                    matched = 1;
                    break;
                }
            }
            Reg[i].HoldRegData = 0;
            if (!matched)
            {
                Reg[Reg_Len].HoldRegData = 0;
                return;
            }
        }
        Reg[Reg_Len].HoldRegData = 0;
    }
}

uint8_t Key_ReadAll(uint8_t mode)
{
    static uint8_t key_up = 1;
    uint8_t keyval = 0;

    if(mode) key_up = 1;

    if(key_up && (KEYI == 1 || KEYII == 1 || KEYPTT == 1))
    {
        HAL_Delay(10);
        key_up = 0;
        
        if(KEYI == 1)   keyval = KEYI_PRES;
        if(KEYII == 1)  keyval = KEYII_PRES;
        if(KEYPTT == 1) keyval = KEYPTT_PRES;
    }
    else if(KEYI == 0 && KEYII == 0 && KEYPTT == 0)
    {
        key_up = 1;
    }
    return keyval;
}

void Key_Task(void)
{
    key_value = Key_ReadAll(1) | 0xA0;

    if(key_value != last_key_value)
    {
        last_key_value = key_value;
        //按键状态发生变化，发送到 RS485
        RS485_Send(&key_value, 1); // 发送按键状态到 RS485
    }
}

//干簧管的状态
uint8_t Reed_Switch_Value(void)
{
    uint8_t reed_value = 0;
    if(REED_SWITCH == 1)
    {
        HAL_Delay(10);
        if(REED_SWITCH == 1)
        {
            reed_value = REED_SWITCH_OFF;
        }
    }
    else if(REED_SWITCH == 0)
    {
        reed_value = REED_SWITCH_ON;
    }
    return reed_value;
}


void Reed_Task(void)
{
    Reed_value = Reed_Switch_Value();
    if(Reed_value != Last_reed_value)
    {
        Last_reed_value = Reed_value;
        RS485_Send(&Reed_value, 1); // 发送干簧管状态到 RS485
    }
}

uint8_t Led_Mt_flag(void)
{
    return MT_Flag = LED_MT;
}

/* -------------------------------------KEY端口定义-------------------------------------------------- */
void KEY_0(uint8_t x) {
    HAL_GPIO_WritePin(Key_0_GPIO_Port, Key_0_Pin, x ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

void KEY_1(uint8_t x) {
    HAL_GPIO_WritePin(Key_1_GPIO_Port, Key_1_Pin, x ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

void KEY_2(uint8_t x) {
    HAL_GPIO_WritePin(Key_2_GPIO_Port, Key_2_Pin, x ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

void KEY_3(uint8_t x) {
    HAL_GPIO_WritePin(Key_3_GPIO_Port, Key_3_Pin, x ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

void KEY_4(uint8_t x) {
    HAL_GPIO_WritePin(Key_4_GPIO_Port, Key_4_Pin, x ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

void KEY_5(uint8_t x) {
    HAL_GPIO_WritePin(Key_5_GPIO_Port, Key_5_Pin, x ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

void KEY_6(uint8_t x) {
    HAL_GPIO_WritePin(Key_6_GPIO_Port, Key_6_Pin, x ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

void KEY_7(uint8_t x) {
    HAL_GPIO_WritePin(Key_7_GPIO_Port, Key_7_Pin, x ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

void KEY_8(uint8_t x) {
    HAL_GPIO_WritePin(Key_8_GPIO_Port, Key_8_Pin, x ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

void KEY_9(uint8_t x) {
    HAL_GPIO_WritePin(Key_9_GPIO_Port, Key_9_Pin, x ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

void KEY_STAR(uint8_t x) {
    HAL_GPIO_WritePin(Key_STAR_GPIO_Port, Key_STAR_Pin, x ? GPIO_PIN_SET : GPIO_PIN_RESET);
}   // *

void KEY_POUND(uint8_t x) {
    HAL_GPIO_WritePin(Key_POUND_GPIO_Port, Key_POUND_Pin, x ? GPIO_PIN_SET : GPIO_PIN_RESET);
}   // #

void KEY_MT(uint8_t x) {
    HAL_GPIO_WritePin(Key_MT_GPIO_Port, Key_MT_Pin, x ? GPIO_PIN_SET : GPIO_PIN_RESET);
}   // 免提

 void KEY_GD(uint8_t x) {
    HAL_GPIO_WritePin(Key_MT_GPIO_Port, Key_MT_Pin, x ? GPIO_PIN_SET : GPIO_PIN_RESET);
 }   // 免提










