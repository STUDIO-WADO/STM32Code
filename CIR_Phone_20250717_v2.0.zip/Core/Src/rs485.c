#include "rs485.h"
#include "usart.h"
#include "crc.h"
#include <string.h>

RS485_MSG rs485_msg;
RS485_State rs485_state = RS485_HEAD;
uint16_t cnt;

HOLDREG Reg[REG_SIZE]= {{0x0000, 0x00, 0},                    
                {0x0001, 0x00, 0},                    
                {0x0002, 0x00, 0},                    
                {0x0003, 0x00, 0},                    
                {0x0004, 0x00, 0},                    
                {0x0005, 0x00, 0},                    
                {0x0006, 0x00, 0},                    
                {0x0007, 0x00, 0},                    
                {0x0008, 0x00, 0},
                {0x0009, 0x00, 0}
};

void RS485_Process(void)
{
    uint8_t ch = 0;
    uint16_t crc_calc = 0;
    uint8_t crc_h = 0;
    uint8_t crc_l = 0;

    while(UART1GetChar(&ch) == 0)
    {
        switch(rs485_state)
        {
            case RS485_HEAD:
                if(ch == 0xAA)
                {
                    rs485_msg.rx_buf[0] = ch;
                    rs485_msg.rx_len = 1;
                    rs485_state = RS485_ADDR;
                }
                break;

            case RS485_ADDR:
                if(ch == 0x40)
                {
                    rs485_msg.rx_buf[rs485_msg.rx_len++] = ch;
                    rs485_state = RS485_LEN;
                }
                else
                {
                    rs485_state = RS485_HEAD;
                }
                break;

            case RS485_LEN:
                if(ch <= BUF_SIZE - 6)
                {
                    rs485_msg.rx_buf[rs485_msg.rx_len++] = ch;
                    rs485_msg.frame_len = ch + 6; // 包头(1) + 地址(1) + 长度(1) + 数据(n) + 校验(2) + 包尾(1)
                    if(rs485_msg.frame_len > BUF_SIZE)
                    {
                        rs485_state = RS485_HEAD;
                    }
                    else
                    {
                        rs485_state = RS485_DATA;
                    }
                }
                else
                {
                    rs485_state = RS485_HEAD;
                }
                break;

            case RS485_DATA:
                rs485_msg.rx_buf[rs485_msg.rx_len++] = ch;
                if(rs485_msg.rx_len >= rs485_msg.frame_len - 1) // 数据接收完毕，等待包尾
                {
                    //crc校验 不包含CRC和包尾
                    crc_calc = my_crc(rs485_msg.rx_buf, rs485_msg.frame_len - 3);
                    crc_h = (crc_calc >> 8) & 0xFF;
                    crc_l = crc_calc & 0xFF;

                    if(crc_h == rs485_msg.rx_buf[rs485_msg.frame_len - 3] &&
                       crc_l == rs485_msg.rx_buf[rs485_msg.frame_len - 2])
                    {
                        rs485_state = RS485_END;
                    }
                    else
                    {
                        rs485_state = RS485_HEAD;
                    }
                }
                break;
            
            case RS485_END:
                if(ch == 0xEE)
                {
                    //接收成功，处理数据
                    rs485_msg.rx_buf[rs485_msg.rx_len++] = ch;

                    //将数据保存到全局变量，供其他任务使用
                    RS485_Data_Copy();

                    if(cnt <= 1000)
                    {
                        cnt++;
                    }else
                    {
                        cnt = 0;
                    }
                    rs485_state = RS485_HEAD;
                }
                else
                {
                    //包尾错误，丢弃数据
                    rs485_state = RS485_HEAD;
                }
                break;

            default:
                rs485_state = RS485_HEAD;
                break;  
        }
    }
}

void RS485_Send(uint8_t *data, uint8_t len)
{
    if(len > BUF_SIZE - 6) return; // 数据过长，丢弃

    RS485DIR_TX; // 切换到发送模式

    rs485_msg.tx_buf[0] = 0xAA; // 包头
    rs485_msg.tx_buf[1] = 0x40; // 地址
    rs485_msg.tx_buf[2] = len;  // 长度
    memcpy(&rs485_msg.tx_buf[3], data, len); // 数据

    uint16_t crc = my_crc(rs485_msg.tx_buf, len + 3); // 计算CRC
    rs485_msg.tx_buf[len + 3] = (crc >> 8) & 0xFF; // CRC高字节
    rs485_msg.tx_buf[len + 4] = crc & 0xFF;        // CRC低字节
    rs485_msg.tx_buf[len + 5] = 0xEE;              // 包尾

    HAL_UART_Transmit(&huart1, rs485_msg.tx_buf, len + 6, HAL_MAX_DELAY); // 发送数据

    RS485DIR_RX; // 切换回接收模式
}

volatile uint8_t g_hangup_request = 0;

void RS485_Data_Copy(void)
{
    uint8_t rx_data_size = rs485_msg.rx_buf[2];
    for(uint8_t i = 0; i < rx_data_size; i++)
    {
        Reg[i].HoldRegData = rs485_msg.rx_buf[3 + i];
    }
    
    if(rx_data_size == 1 && rs485_msg.rx_buf[3] == 0x6B)
    {
        g_hangup_request = 1;
    }
}
