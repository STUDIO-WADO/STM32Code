#ifndef __EBC_PMOS_H__
#define __EBC_PMOS_H__

#include "gpio.h"

#define OUT_1_Pin GPIO_PIN_0
#define OUT_1_GPIO_Port GPIOC
#define OUT_2_Pin GPIO_PIN_1
#define OUT_2_GPIO_Port GPIOC
#define OUT_3_Pin GPIO_PIN_2
#define OUT_3_GPIO_Port GPIOC
#define OUT_4_Pin GPIO_PIN_3
#define OUT_4_GPIO_Port GPIOC
#define OUT_5_Pin GPIO_PIN_0
#define OUT_5_GPIO_Port GPIOA
#define OUT_6_Pin GPIO_PIN_1
#define OUT_6_GPIO_Port GPIOA
#define OUT_7_Pin GPIO_PIN_2
#define OUT_7_GPIO_Port GPIOA
#define OUT_8_Pin GPIO_PIN_3
#define OUT_8_GPIO_Port GPIOA
#define OUT_9_Pin GPIO_PIN_4
#define OUT_9_GPIO_Port GPIOA
#define OUT_10_Pin GPIO_PIN_5
#define OUT_10_GPIO_Port GPIOA
#define OUT_11_Pin GPIO_PIN_6
#define OUT_11_GPIO_Port GPIOA
#define OUT_12_Pin GPIO_PIN_7
#define OUT_12_GPIO_Port GPIOA
#define OUT_13_Pin GPIO_PIN_4
#define OUT_13_GPIO_Port GPIOC
#define OUT_14_Pin GPIO_PIN_5
#define OUT_14_GPIO_Port GPIOC
#define OUT_15_Pin GPIO_PIN_0
#define OUT_15_GPIO_Port GPIOB
#define OUT_16_Pin GPIO_PIN_1
#define OUT_16_GPIO_Port GPIOB

#define PMOS_OUT_NUM 16

void PMOS_GPIO_Init(void);
uint8_t PMOS_SetOutput(uint8_t *can1_data);
void ebc_pmos_output_send_buf(uint8_t *can1_data);

#endif
