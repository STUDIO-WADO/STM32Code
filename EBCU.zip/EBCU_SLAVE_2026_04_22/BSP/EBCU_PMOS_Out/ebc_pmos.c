#include "ebc_pmos.h"
#include "dip_switch.h"
#include "ebc_can.h"

uint16_t pmos_outvalue = 0;

extern TxMsg can1_tx_msg;
extern uint8_t CAN1_life;
extern volatile uint8_t Slave_ID;

typedef struct {
    GPIO_TypeDef *port;
    uint16_t pin;
} PMOS_GPIO_T;

static const PMOS_GPIO_T pmos_table[PMOS_OUT_NUM] = {
    {OUT_1_GPIO_Port, OUT_1_Pin},
    {OUT_2_GPIO_Port, OUT_2_Pin},
    {OUT_3_GPIO_Port, OUT_3_Pin},
    {OUT_4_GPIO_Port, OUT_4_Pin},
    {OUT_5_GPIO_Port, OUT_5_Pin},
    {OUT_6_GPIO_Port, OUT_6_Pin},
    {OUT_7_GPIO_Port, OUT_7_Pin},
    {OUT_8_GPIO_Port, OUT_8_Pin},
    {OUT_9_GPIO_Port, OUT_9_Pin},
    {OUT_10_GPIO_Port, OUT_10_Pin},
    {OUT_11_GPIO_Port, OUT_11_Pin},
    {OUT_12_GPIO_Port, OUT_12_Pin},
    {OUT_13_GPIO_Port, OUT_13_Pin},
    {OUT_14_GPIO_Port, OUT_14_Pin},
    {OUT_15_GPIO_Port, OUT_15_Pin},
    {OUT_16_GPIO_Port, OUT_16_Pin}
};

//GPIO初始化
void PMOS_GPIO_Init(void)
{
    GPIO_InitTypeDef PMOS_GPIO_InitStruct = {0};

    /* GPIO Ports Clock Enable */
    __HAL_RCC_GPIOH_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

      /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, OUT_1_Pin|OUT_2_Pin|OUT_3_Pin|OUT_4_Pin
                          |OUT_13_Pin|OUT_14_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, OUT_5_Pin|OUT_6_Pin|OUT_7_Pin|OUT_8_Pin
                          |OUT_9_Pin|OUT_10_Pin|OUT_11_Pin|OUT_12_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, OUT_15_Pin|OUT_16_Pin, GPIO_PIN_SET);

  /*Configure GPIO pins : OUT_1_Pin OUT_2_Pin OUT_3_Pin OUT_4_Pin
                           OUT_13_Pin OUT_14_Pin */
  PMOS_GPIO_InitStruct.Pin = OUT_1_Pin|OUT_2_Pin|OUT_3_Pin|OUT_4_Pin
                          |OUT_13_Pin|OUT_14_Pin;
  PMOS_GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  PMOS_GPIO_InitStruct.Pull = GPIO_NOPULL;
  PMOS_GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &PMOS_GPIO_InitStruct);

  /*Configure GPIO pins : OUT_5_Pin OUT_6_Pin OUT_7_Pin OUT_8_Pin
                           OUT_9_Pin OUT_10_Pin OUT_11_Pin OUT_12_Pin */
  PMOS_GPIO_InitStruct.Pin = OUT_5_Pin|OUT_6_Pin|OUT_7_Pin|OUT_8_Pin
                          |OUT_9_Pin|OUT_10_Pin|OUT_11_Pin|OUT_12_Pin;
  PMOS_GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  PMOS_GPIO_InitStruct.Pull = GPIO_NOPULL;
  PMOS_GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &PMOS_GPIO_InitStruct);

  /*Configure GPIO pins : OUT_15_Pin OUT_16_Pin */
  PMOS_GPIO_InitStruct.Pin = OUT_15_Pin|OUT_16_Pin;
  PMOS_GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  PMOS_GPIO_InitStruct.Pull = GPIO_NOPULL;
  PMOS_GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &PMOS_GPIO_InitStruct);

}

uint8_t PMOS_SetOutput(uint8_t *can1_data)
{
    pmos_outvalue = ((uint16_t)can1_data[4] << 8) | can1_data[3];

    for (uint8_t i = 0; i < PMOS_OUT_NUM; i++)
    {
        GPIO_PinState state = (pmos_outvalue & (1 << i)) ? GPIO_PIN_RESET : GPIO_PIN_SET;
        HAL_GPIO_WritePin(pmos_table[i].port, pmos_table[i].pin, state);
    }
    ebc_pmos_output_send_buf(can1_data);
    return 0;
}

//将16路输出设置的值通过CAN发送出去
void ebc_pmos_output_send_buf(uint8_t *can1_data)
{
    can1_tx_msg.CAN_SEND_BUF[0][0] = 0x01;
    can1_tx_msg.CAN_SEND_BUF[0][1] = can1_tx_msg.can_ID;
    can1_tx_msg.CAN_SEND_BUF[0][2] = can1_tx_msg.board_type;
    can1_tx_msg.CAN_SEND_BUF[0][3] = can1_data[3];
    can1_tx_msg.CAN_SEND_BUF[0][4] = can1_data[4];
    can1_tx_msg.CAN_SEND_BUF[0][5] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[0][6] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[0][7] = 0x00;

    can1_tx_msg.CAN_SEND_BUF[1][0] = 0x02;
    can1_tx_msg.CAN_SEND_BUF[1][1] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[1][2] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[1][3] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[1][4] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[1][5] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[1][6] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[1][7] = 0x00;

    can1_tx_msg.CAN_SEND_BUF[2][0] = 0x03;
    can1_tx_msg.CAN_SEND_BUF[2][1] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[2][2] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[2][3] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[2][4] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[2][5] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[2][6] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[2][7] = CAN1_life;

    for(uint8_t i = 0; i < 3; i++)
    {
        can1_send_msg(Slave_ID, can1_tx_msg.CAN_SEND_BUF[i], 8);
    }
}
