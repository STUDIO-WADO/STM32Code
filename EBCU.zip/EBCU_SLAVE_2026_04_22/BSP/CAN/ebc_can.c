#include "ebc_can.h"
#include "can.h"
#include "ebc_pmos.h"
#include "dip_switch.h"
#include "ebc_digital_input.h"

CAN_TxHeaderTypeDef g_can1_txheader;    /* 发送参数句柄 */
CAN_RxHeaderTypeDef g_can1_rxheader;    /* 接收参数句柄 */

CAN_TxHeaderTypeDef g_can2_txheader;    /* 发送参数句柄 */
CAN_RxHeaderTypeDef g_can2_rxheader;    /* 接收参数句柄 */

RxMsg can1_msg;
RxMsg can2_msg;

TxMsg can1_tx_msg;

uint8_t CAN1_RxBuf[8];//接收数据缓冲区
uint8_t CAN2_RxBuf[8];//接收数据缓冲区

uint8_t can1_rec_buf1[3][8];// CAN1接收数据缓冲区，3条消息，每条消息8字节

volatile uint8_t can1_rx_flag = 0;
volatile uint8_t can2_rx_flag = 0;

extern volatile uint8_t dip_switch_high4_value;
extern volatile uint8_t dip_switch_low4_value;

extern volatile uint8_t Slave_ID;
extern volatile uint8_t Master_ID;
extern volatile uint8_t Type_BOARD;

//CAN中断回调函数
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
  if(hcan->Instance == CAN1)
  {
    if(can1_receive_msg(Master_ID, CAN1_RxBuf))
    {
      if(g_can1_rxheader.StdId == Master_ID)
      {
        /* 在这里对接收到的数据进行处理 */
        can1_msg.stdID = g_can1_rxheader.StdId;
        can1_msg.IDE = g_can1_rxheader.IDE;
        can1_msg.RTR = g_can1_rxheader.RTR;
        can1_msg.DLC = g_can1_rxheader.DLC;

        for(uint8_t i = 0; i < can1_msg.DLC; i++)
        {
          can1_msg.CAN_DATA[CAN1_RxBuf[0] - 1][i] = CAN1_RxBuf[i];
        }
        
        can1_rx_flag = 1;    /* 设置接收标志 */
        
      }
    }
  }
}

uint8_t CAN1_FilterConfig(void)
{
  CAN_FilterTypeDef can1FilterConfig;

  can1FilterConfig.FilterActivation = ENABLE;
  can1FilterConfig.FilterBank = 0;
  can1FilterConfig.FilterFIFOAssignment = CAN_FILTER_FIFO0;
  can1FilterConfig.FilterIdHigh = 0x0000;
  can1FilterConfig.FilterIdLow = 0x0000;
  can1FilterConfig.FilterMaskIdHigh = 0x0000;
  can1FilterConfig.FilterMaskIdLow = 0x0000;
  can1FilterConfig.FilterMode = CAN_FILTERMODE_IDMASK;
  can1FilterConfig.FilterScale = CAN_FILTERSCALE_32BIT;
  can1FilterConfig.SlaveStartFilterBank = 14;

  if(HAL_CAN_ConfigFilter(&hcan1, &can1FilterConfig) != HAL_OK)
  {
    /* Filter configuration Error */
    return 1;
  }

  if (HAL_CAN_Start(&hcan1) != HAL_OK)
  {
    return 2;
  }

  if (HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING) != HAL_OK) {
    Error_Handler();
  }
  
  return 0;
}

uint8_t can1_send_msg(uint32_t id, uint8_t *msg, uint8_t len)
{
  uint16_t t = 0;
  uint32_t TxMailbox = CAN_TX_MAILBOX0;
  
  g_can1_txheader.StdId = id;         /* 标准标识符 */
  g_can1_txheader.ExtId = 0x00;         /* 扩展标识符(29位) */
  g_can1_txheader.IDE = CAN_ID_STD;   /* 使用标准帧 */
  g_can1_txheader.RTR = CAN_RTR_DATA; /* 数据帧 */
  g_can1_txheader.DLC = len;

  if (HAL_CAN_AddTxMessage(&hcan1, &g_can1_txheader, msg, &TxMailbox) != HAL_OK) /* 发送消息 */
  {
    return 1;
  }
  
  while (HAL_CAN_GetTxMailboxesFreeLevel(&hcan1) != 3)   /* 等待发送完成,所有邮箱为空 */
  {
      t++;
      
      if (t > 0xFFF)
      {
        HAL_CAN_AbortTxRequest(&hcan1, TxMailbox);     /* 超时，直接中止邮箱的发送请求 */
        return 1;
      }
  }
  
  return 0;
}

uint8_t can1_receive_msg(uint32_t id, uint8_t *buf)
{
    if (HAL_CAN_GetRxFifoFillLevel(&hcan1, CAN_RX_FIFO0) == 0)     /* 没有接收到数据 */
    {
        return 0;
    }

    if (HAL_CAN_GetRxMessage(&hcan1, CAN_RX_FIFO0, &g_can1_rxheader, buf) != HAL_OK)  /* 读取数据 */
    {
        return 0;
    }

    if (g_can1_rxheader.StdId!= id || g_can1_rxheader.IDE != CAN_ID_STD || g_can1_rxheader.RTR != CAN_RTR_DATA)       /* 接收到的ID不对 / 不是标准帧 / 不是数据帧 */
    {
        return 0;    
    }

    return g_can1_rxheader.DLC;

}

//CAN1将接收到的数据进行处理
uint8_t CAN1_RxMsgProcess(void)
{
    if (can1_rx_flag)   /* 接收标志位 */
    {
        can1_rx_flag = 0;    /* 清除接收标志 */

        // 根据接收到的CAN数据进行处理
        switch (Type_BOARD)
        {
        case TYPE_BORAD_16PMOS_OUT:
            /* code */
            PMOS_SetOutput(can1_msg.CAN_DATA[0]);
            break;

        case TYPE_BORAD_16DRY_INPUT:
            /* 返回16路数字输入状态 */
            ebc_digital_input_read();
            break;
        
        default:
            break;
        }
    }

  return 1;
}

