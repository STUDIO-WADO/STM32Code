#ifndef __EBC_CAN_H__
#define __EBC_CAN_H__

#include "main.h"

typedef struct
{
  uint32_t stdID;
  uint32_t IDE;
  uint32_t RTR;
  uint32_t DLC;
  uint8_t CAN_DATA[3][8];
}RxMsg;

typedef struct {
    uint8_t can_ID;
    uint8_t board_type;
    uint8_t CAN_SEND_BUF[3][8];
}TxMsg;

uint8_t CAN1_FilterConfig(void);
uint8_t can1_send_msg(uint32_t id, uint8_t *msg, uint8_t len);
uint8_t can1_receive_msg(uint32_t id, uint8_t *buf);
uint8_t CAN1_RxMsgProcess(void);

#endif
