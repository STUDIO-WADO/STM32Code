#ifndef __EBC_DIGITAL_INPUT_H__
#define __EBC_DIGITAL_INPUT_H__

#include "gpio.h"

#define DIGITAL_INPUT_NUM 16

#define Signal_1_Pin GPIO_PIN_0
#define Signal_1_GPIO_Port GPIOC
#define Signal_2_Pin GPIO_PIN_1
#define Signal_2_GPIO_Port GPIOC
#define Signal_3_Pin GPIO_PIN_2
#define Signal_3_GPIO_Port GPIOC
#define Signal_4_Pin GPIO_PIN_3
#define Signal_4_GPIO_Port GPIOC
#define Signal_5_Pin GPIO_PIN_0
#define Signal_5_GPIO_Port GPIOA
#define Signal_6_Pin GPIO_PIN_1
#define Signal_6_GPIO_Port GPIOA
#define Signal_7_Pin GPIO_PIN_2
#define Signal_7_GPIO_Port GPIOA
#define Signal_8_Pin GPIO_PIN_3
#define Signal_8_GPIO_Port GPIOA
#define Signal_9_Pin GPIO_PIN_4
#define Signal_9_GPIO_Port GPIOA
#define Signal_10_Pin GPIO_PIN_5
#define Signal_10_GPIO_Port GPIOA
#define Signal_11_Pin GPIO_PIN_6
#define Signal_11_GPIO_Port GPIOA
#define Signal_12_Pin GPIO_PIN_7
#define Signal_12_GPIO_Port GPIOA
#define Signal_13_Pin GPIO_PIN_4
#define Signal_13_GPIO_Port GPIOC
#define Signal_14_Pin GPIO_PIN_5
#define Signal_14_GPIO_Port GPIOC
#define Signal_15_Pin GPIO_PIN_0
#define Signal_15_GPIO_Port GPIOB
#define Signal_16_Pin GPIO_PIN_1
#define Signal_16_GPIO_Port GPIOB

void EBC_DigitalInput_GPIO_Init(void);
uint16_t EBC_DigitalInput_Read(uint8_t index);
uint16_t EBC_DigitalInput_ReadAll(void);
void ebc_digital_input_read(void);
void ebc_digital_input_send_buf(uint8_t *buf);

#endif
