#include "ebc_digital_input.h"
#include "ebc_can.h"

extern uint8_t CAN1_life;
extern volatile uint8_t Slave_ID;
extern TxMsg can1_tx_msg;

typedef struct {
    GPIO_TypeDef *port;
    uint16_t pin;
} EBC_DIGITAL_INPUT_GPIO_T;

static const EBC_DIGITAL_INPUT_GPIO_T ebc_digital_input_table[DIGITAL_INPUT_NUM] = {
    {Signal_1_GPIO_Port, Signal_1_Pin},
    {Signal_2_GPIO_Port, Signal_2_Pin},
    {Signal_3_GPIO_Port, Signal_3_Pin},
    {Signal_4_GPIO_Port, Signal_4_Pin},
    {Signal_5_GPIO_Port, Signal_5_Pin},
    {Signal_6_GPIO_Port, Signal_6_Pin},
    {Signal_7_GPIO_Port, Signal_7_Pin},
    {Signal_8_GPIO_Port, Signal_8_Pin},
    {Signal_9_GPIO_Port, Signal_9_Pin},
    {Signal_10_GPIO_Port, Signal_10_Pin},
    {Signal_11_GPIO_Port, Signal_11_Pin},
    {Signal_12_GPIO_Port, Signal_12_Pin},
    {Signal_13_GPIO_Port, Signal_13_Pin},
    {Signal_14_GPIO_Port, Signal_14_Pin},
    {Signal_15_GPIO_Port, Signal_15_Pin},
    {Signal_16_GPIO_Port, Signal_16_Pin}
};

//GPIO初始化
void EBC_DigitalInput_GPIO_Init(void)
{
    GPIO_InitTypeDef DigitalInput_GPIO_InitStruct = {0};

    /* GPIO Ports Clock Enable */
    __HAL_RCC_GPIOH_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    /*Configure GPIO pins : Signal_1_Pin Signal_2_Pin Signal_3_Pin Signal_4_Pin
                           Signal_13_Pin Signal_14_Pin */
    DigitalInput_GPIO_InitStruct.Pin = Signal_1_Pin|Signal_2_Pin|Signal_3_Pin|Signal_4_Pin
                            |Signal_13_Pin|Signal_14_Pin;
    DigitalInput_GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    DigitalInput_GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOC, &DigitalInput_GPIO_InitStruct);

    /*Configure GPIO pins : Signal_5_Pin Signal_6_Pin Signal_7_Pin Signal_8_Pin
                            Signal_9_Pin Signal_10_Pin Signal_11_Pin Signal_12_Pin */
    DigitalInput_GPIO_InitStruct.Pin = Signal_5_Pin|Signal_6_Pin|Signal_7_Pin|Signal_8_Pin
                            |Signal_9_Pin|Signal_10_Pin|Signal_11_Pin|Signal_12_Pin;
    DigitalInput_GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    DigitalInput_GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &DigitalInput_GPIO_InitStruct);

    /*Configure GPIO pins : Signal_15_Pin Signal_16_Pin */
    DigitalInput_GPIO_InitStruct.Pin = Signal_15_Pin|Signal_16_Pin;
    DigitalInput_GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    DigitalInput_GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOB, &DigitalInput_GPIO_InitStruct);

}

uint16_t EBC_DigitalInput_Read(uint8_t index)
{
    if (index == 0 || index > DIGITAL_INPUT_NUM)
        return 0xFF;

    GPIO_PinState state = HAL_GPIO_ReadPin(
        ebc_digital_input_table[index - 1].port,
        ebc_digital_input_table[index - 1].pin
    );

    return (state == GPIO_PIN_SET) ? 0 : 1;  // ON=0, OFF=1
}

uint16_t EBC_DigitalInput_ReadAll(void)
{
    uint16_t value = 0;

    for (uint8_t i = 0; i < DIGITAL_INPUT_NUM; i++)
    {
        uint16_t input = EBC_DigitalInput_Read(i + 1);
        if (input == 1) value |= (1 << i);
    }

    return value;
}

uint8_t ebc_digital_input_value[DIGITAL_INPUT_NUM];
uint16_t ebc_digital_input_all_value;
uint8_t ebc_digital_input_all_value_can1_tx[2];

void ebc_digital_input_read(void)
{
    for (uint8_t i = 0; i < DIGITAL_INPUT_NUM; i++)
    {
        ebc_digital_input_value[i] = EBC_DigitalInput_Read(i + 1);
    }

    ebc_digital_input_all_value = EBC_DigitalInput_ReadAll();

    // 将16位的输入状态分成2个字节，准备发送
    ebc_digital_input_all_value_can1_tx[0] = (uint8_t)(ebc_digital_input_all_value & 0xFF); // 低字节
    ebc_digital_input_all_value_can1_tx[1] = (uint8_t)((ebc_digital_input_all_value >> 8) & 0xFF); // 高字节

    // CAN发送函数，发送到Master_ID，数据长度为2字节
    ebc_digital_input_send_buf(ebc_digital_input_all_value_can1_tx);
}

void ebc_digital_input_send_buf(uint8_t *buf)
{
    can1_tx_msg.CAN_SEND_BUF[0][0] = 0x01;
    can1_tx_msg.CAN_SEND_BUF[0][1] = can1_tx_msg.can_ID;
    can1_tx_msg.CAN_SEND_BUF[0][2] = can1_tx_msg.board_type;
    can1_tx_msg.CAN_SEND_BUF[0][3] = buf[0];
    can1_tx_msg.CAN_SEND_BUF[0][4] = buf[1];
    can1_tx_msg.CAN_SEND_BUF[0][5] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[0][6] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[0][7] = 0x00;

    can1_tx_msg.CAN_SEND_BUF[1][0] = 0x02;
    can1_tx_msg.CAN_SEND_BUF[1][1] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[1][2] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[1][3] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[1][4] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[1][5] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[1][6] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[1][7] = 0x00;

    can1_tx_msg.CAN_SEND_BUF[2][0] = 0x03;
    can1_tx_msg.CAN_SEND_BUF[2][1] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[2][2] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[2][3] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[2][4] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[2][5] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[2][6] = 0x00;
    can1_tx_msg.CAN_SEND_BUF[2][7] = CAN1_life;

    for(uint8_t i = 0; i < 3; i++)
    {
        can1_send_msg(Slave_ID, can1_tx_msg.CAN_SEND_BUF[i], 8);
    }
}
