#include "dip_switch.h"
#include "ebc_pmos.h"
#include "ebc_digital_input.h"
#include "ebc_can.h"

uint8_t dip_switch_value[8];

volatile uint8_t dip_switch_all_value;
volatile uint8_t dip_switch_high4_value;
volatile uint8_t dip_switch_low4_value;

volatile uint8_t Slave_ID;
volatile uint8_t Master_ID;
volatile uint8_t Type_BOARD;

extern TxMsg can1_tx_msg;

typedef struct {
    GPIO_TypeDef *port;
    uint16_t pin;
} DIP_SW_GPIO_T;

static const DIP_SW_GPIO_T dip_sw_table[DIP_SW_NUM] = {
    {BM1_GPIO_Port, BM1_Pin},
    {BM2_GPIO_Port, BM2_Pin},
    {BM3_GPIO_Port, BM3_Pin},
    {BM4_GPIO_Port, BM4_Pin},
    {BM5_GPIO_Port, BM5_Pin},
    {BM6_GPIO_Port, BM6_Pin},
    {BM7_GPIO_Port, BM7_Pin},
    {BM8_GPIO_Port, BM8_Pin}
};

uint8_t DIP_Switch_Read(uint8_t index)
{
    if (index == 0 || index > DIP_SW_NUM)
        return 0xFF;

    GPIO_PinState state = HAL_GPIO_ReadPin(
        dip_sw_table[index - 1].port,
        dip_sw_table[index - 1].pin
    );

    return (state == GPIO_PIN_SET) ? 1 : 0;  // ON=1, OFF=0
}

// 读取所有位组成字节
uint8_t DIP_Switch_ReadAll(void)
{
    uint8_t value = 0;

    for (uint8_t i = 0; i < DIP_SW_NUM; i++)
    {
        uint8_t sw = DIP_Switch_Read(i + 1);
        if (sw == 1) value |= (1 << i);
    }

    return value;
}

//获取拨码高4位状态低位补0 设备类型
uint8_t DIP_Switch_ReadHigh4(void)
{
    uint8_t value = 0;

    for (uint8_t i = 4; i < DIP_SW_NUM; i++)
    {
        uint8_t sw = DIP_Switch_Read(i + 1);
        if (sw == 1) value |= (1 << i);
    }

    return value;
}

// 获取拨码低4位状态高位补0 设备ID
uint8_t DIP_Switch_ReadLow4(void)
{
    uint8_t value = 0;

    for (uint8_t i = 0; i < 4; i++)
    {
        uint8_t sw = DIP_Switch_Read(i + 1);
        if (sw == 1) value |= (1 << i);
    }

    return value;
}

// 分配ID和类型
void DIP_Switch_Init(void)
{
    can1_tx_msg.can_ID = DIP_Switch_ReadLow4();
    can1_tx_msg.board_type = DIP_Switch_ReadHigh4();

    switch(can1_tx_msg.board_type)
    {
        case EBC_PMOS_OUT_TYPE:
            Type_BOARD = 1;
            PMOS_GPIO_Init();
            break;
        
        case EBC_DIGITAL_INPUT_TYPE:
            Type_BOARD = 3;
            EBC_DigitalInput_GPIO_Init();
            break;

        default:
            break;
    }

    switch(can1_tx_msg.can_ID)
    {
        case 0x01:Slave_ID = 0x21; Master_ID = 0x12; break;
        case 0x02:Slave_ID = 0x31; Master_ID = 0x13; break;
        default:Slave_ID = 0x61; Master_ID = 0x16; break;
    }
}

// void dip_switch_test(void)
// {
//     for (uint8_t i = 0; i < DIP_SW_NUM; i++)
//     {
//         dip_switch_value[i] = DIP_Switch_Read(i + 1);
//     }

//     dip_switch_all_value = DIP_Switch_ReadAll();
// }
