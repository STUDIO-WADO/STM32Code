#ifndef __DIP_SWITCH_H__
#define __DIP_SWITCH_H__

#include "gpio.h"

// 拨码开关数量
#define DIP_SW_NUM   8

// 板卡类型
#define EBC_PMOS_OUT_TYPE           0x10
#define EBC_DIGITAL_INPUT_TYPE      0x30

#define TYPE_BORAD_16PMOS_OUT     1
#define TYPE_BORAD_16DRY_INPUT    3

// 函数声明
uint8_t DIP_Switch_Read(uint8_t index);
uint8_t DIP_Switch_ReadAll(void);
uint8_t DIP_Switch_ReadHigh4(void);
uint8_t DIP_Switch_ReadLow4(void);
void DIP_Switch_Init(void);

#endif /* __DIP_SWITCH_H__ */
