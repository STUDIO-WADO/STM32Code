#include "ebc_pwmout.h"
#include "ebc_hd7279.h"
#include "ebc_key.h"
#include "tim.h"
#include "ebc_timer.h"

extern volatile uint8_t HD7279_Keyflag;
extern uint8_t HD7279_Keycode;

const uint16_t freq_table[] = {500, 1000, 1500, 2000};
volatile uint8_t freq_index = 0; // 当前频率索引
volatile uint8_t duty_percent = 0; // 当前占空比%

// 更新频率（保持占空比不变）
void Update_Frequency(uint8_t index)
{
    uint16_t arr = freq_table[index];
    // 先算新的CCR，保持占空比
    uint32_t ccr = ((uint32_t)duty_percent * (arr + 1)) / 100;

    // 停止PWM
    HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_1);
    HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_2);

    // 修改ARR和CCR
    __HAL_TIM_SET_AUTORELOAD(&htim3, arr);
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, ccr);
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, ccr);

    // 重启PWM
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);
}

// 更新占空比
void Update_Duty(uint8_t percent)
{
    uint16_t arr = __HAL_TIM_GET_AUTORELOAD(&htim3);
    uint32_t ccr = ((uint32_t)percent * (arr + 1)) / 100;
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, ccr);
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, ccr);
}

void Key_Scan(void)
{
    uint8_t key = HD7279_Read(CMD_READ);
    switch(key)
    {
        case 0x3F:
            freq_index = (freq_index + 1) % 4;
            Update_Frequency(freq_index);
            break;
        case 0x37:
            duty_percent += 10;
            if(duty_percent > 100) duty_percent = 0;
            Update_Duty(duty_percent);
            break;
        default:
            break;
    }
}

void PWM_Init_Config(void)
{
    duty_percent = 50;
    freq_index = 1; // 1000Hz

    Update_Frequency(freq_index);
    Update_Duty(duty_percent);
}
