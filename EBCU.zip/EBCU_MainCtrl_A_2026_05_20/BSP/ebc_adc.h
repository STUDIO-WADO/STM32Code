#ifndef __EBC_ADC_H__
#define __EBC_ADC_H__

#include "main.h"

void ADC_Process(void);
void ADC_Process_ZJJ(void);

#endif
