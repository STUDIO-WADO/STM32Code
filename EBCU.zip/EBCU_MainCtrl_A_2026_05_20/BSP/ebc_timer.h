#ifndef __EBC_TIMER_H__
#define __EBC_TIMER_H__

#include <stdint.h>

void udelay(int us);
void mdelay(int ms);
uint64_t system_get_ns(void);

#endif
