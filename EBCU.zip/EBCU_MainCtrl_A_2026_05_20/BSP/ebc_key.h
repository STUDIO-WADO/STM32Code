#ifndef __EBC_KEY_H__
#define __EBC_KEY_H__

#include "main.h"

void Show_Key(void);

#endif
