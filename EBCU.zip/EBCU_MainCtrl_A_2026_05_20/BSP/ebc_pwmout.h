#ifndef __EBC_PWMOUT_H__
#define __EBC_PWMOUT_H__

#include "main.h"

void Update_Frequency(uint8_t index);
void Update_Duty(uint8_t percent);
void PWM_Init_Config(void);
void Key_Scan(void);

#endif
