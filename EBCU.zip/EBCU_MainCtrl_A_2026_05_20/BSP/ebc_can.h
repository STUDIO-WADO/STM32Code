#ifndef __EBC_CAN_H__
#define __EBC_CAN_H__

#include "main.h"

typedef struct
{
  uint32_t stdID;
  uint32_t IDE;
  uint32_t RTR;
  uint32_t DLC;
  uint8_t CAN_DATA[3][8];
}RxMsg;

typedef struct {
  uint8_t can_ID;
  uint8_t board_type;
  uint8_t CAN_SEND_BUF[3][8];
}TxMsg;

typedef enum {
  ADDress_Board_1 = 1,
  ADDress_Board_2,
  ADDress_Board_3,
  ADDress_Board_4,
  ADDress_Board_NULL
} ADDress_Board_t;

typedef enum {
  Type_Board_16PMOS_output = 1,
  Type_Board_24DRY_output,
  Type_Board_16_input,
  Type_Board_AIAO,
  Type_Board_Speed,
  Type_Board_EP,
}Type_Borad_t;

uint8_t CAN1_FilterConfig(void);
uint8_t CAN2_FilterConfig(void);
uint8_t can1_send_msg(uint32_t id, uint8_t *msg, uint8_t len);
uint8_t can2_send_msg(uint32_t id, uint8_t *msg, uint8_t len);
uint8_t can1_receive_msg(uint32_t id, uint8_t *buf);
uint8_t can2_receive_msg(uint32_t id, uint8_t *buf);

void can2_forward(void);
void can1_forward(void);
void USR_Send_Input_To_ZJJ(uint8_t input_status_1, uint8_t input_status_2);
void updata_msg_buffer(RxMsg *msg_buffer, CAN_RxHeaderTypeDef *rx_header, uint8_t *rx_data);
void can_receive_digital_tube(void);
void ebc_read_board_info(void);
void usr_forward_can1(void);
uint8_t can1_forward_usr(uint8_t type_board, uint8_t *can1_rx_buf);
void ebc_digital_input_forward_can1(void);
void ebc_led_hd7279(uint8_t *led_buf);
#endif
