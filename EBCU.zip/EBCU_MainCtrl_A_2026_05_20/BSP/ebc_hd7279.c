#include "ebc_hd7279.h"
#include "ebc_timer.h"

/**
 * @brief 短延时函数
 * @note 延时约 50 微秒
 */
void short_delay(void)
{
    udelay(50);
}

/**
 * @brief 长延时函数
 * @note 延时约 50 微秒，可根据需要调整
 */
void long_delay(void)
{
    udelay(60);
}

/**
 * @brief 配置 GPIO 引脚模式和上拉/下拉
 * @param mode GPIO 模式（输入/输出等）
 * @param pull 上拉/下拉设置
 * @note 这里固定使用 GPIOC Pin0
 */
static void Data_Config(uint32_t mode, uint32_t pull)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOC_CLK_ENABLE(); // 使能 GPIOC 时钟

    GPIO_InitStruct.Pin = HD7279_DATA_Pin;
    GPIO_InitStruct.Mode = mode;
    GPIO_InitStruct.Pull = pull;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;

    HAL_GPIO_Init(HD7279_DATA_GPIO_Port, &GPIO_InitStruct);
}

/**
 * @brief 将数据线配置为输入模式
 */
void Data_In(void)
{
    Data_Config(GPIO_MODE_INPUT, GPIO_PULLUP);
}

/**
 * @brief 将数据线配置为推挽输出模式
 */
void Data_Out(void)
{
    Data_Config(GPIO_MODE_OUTPUT_PP, GPIO_PULLUP);
}

/**
 * @brief 初始化 HD7279 芯片
 * @note 初始化片选、时钟、数据线，并发送复位命令
 */
void HD7279_Init(void)
{   
    HD7279_NCS(1);   // 片选拉高
    HD7279_CLK(1);   // 时钟拉高
    HD7279_DATA(1);  // 数据拉高
    Data_Out();      // 数据线设为输出
    
    HD7279_NCS(0);
    long_delay();
    HD7279_Send_Byte(CMD_RESET); // 发送复位命令
    HD7279_NCS(1);
    HAL_Delay(50); // 复位后等待HD7279初始化完成
}

/**
 * @brief 向 HD7279 发送一个字节
 * @param data 要发送的数据
 * @note 通过串行接口逐位发送
 */
void HD7279_Send_Byte(uint8_t data)
{
    uint8_t i;

    Data_Out();      // 确保数据线为输出
    for(i = 0; i < 8; i++)
    {
        if(data & 0x80) HD7279_DATA(1); // 发送最高位
        else             HD7279_DATA(0);

        HD7279_CLK(1);  // 时钟拉高，数据锁存
        short_delay();
        HD7279_CLK(0);  // 时钟拉低
        short_delay();

        data <<= 1;     // 左移一位，准备发送下一位
    }
}

/**
 * @brief 从 HD7279 接收一个字节
 * @return 接收到的数据
 * @note 通过串行接口逐位读取
 */
uint8_t HD7279_Receive_Byte(void)
{
    uint8_t i;
    uint8_t data = 0;
    Data_In(); // 设置数据线为输入

    for(i = 0; i < 8; i++)
    {
        HD7279_CLK(1);
        short_delay();

        data <<= 1; // 左移一位，为读取新位腾出空间
        if(HD7279_GET_DATA_PIN) 
            data |= 0x01; // 读取数据线状态
        HD7279_CLK(1);   // 再拉高
        short_delay();
        HD7279_CLK(0);
        short_delay();
    } 
    return data;
}

/**
 * @brief 向 HD7279 写入命令和数据
 * @param cmd 命令字节
 * @param data 数据字节
 */
void HD7279_Write(uint8_t cmd, uint8_t data)
{
    HD7279_NCS(0);       // CS拉低
    long_delay();        // ≥50µs
    HD7279_Send_Byte(cmd);           // 发送命令
    long_delay();        // 字节间延时 ≥50µs
    HD7279_Send_Byte(data);
    HD7279_NCS(1);       // CS拉高，结束通信
}

/**
 * @brief 向 HD7279 发送读取命令并返回数据
 * @param cmd 命令字节
 * @return 读取到的数据字节
 */
uint8_t HD7279_Read(uint8_t cmd)
{
    uint8_t data;
    HD7279_NCS(0);       // CS拉低
    long_delay();        // ≥50µs
    HD7279_Send_Byte(cmd);           // 发送读取命令
    long_delay();
    data = HD7279_Receive_Byte();
    HD7279_NCS(1);       // CS拉高
    return data;
}

void hd7279_test(void)
{
    HD7279_Write(0x84, 0x00);
    HD7279_Write(0x85, 0x00);
    HD7279_Write(0x86, 0x00);
    HD7279_Write(0x87, 0x00);
}
