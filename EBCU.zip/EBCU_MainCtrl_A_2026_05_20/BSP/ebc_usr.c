#include "ebc_usr.h"
#include "usart.h"
#include "dip_switch.h"
#include "crc16.h"
#include "ebc_can.h"

ebc_usr_msg_t usr_msg;

uint16_t cnt;
uint8_t usr_zjj_buf[32];

extern uint8_t Board_Address;
extern volatile uint8_t uart2_tx_busy;
extern uint8_t adc_send_buf[32];
extern uint8_t HD7279_Keycode;

extern uint8_t zjj_input_status_1;
extern uint8_t zjj_input_status_2;

void Usr_Process(void)
{
    static uint8_t state = 0;
    static uint8_t buf[32];
    static uint8_t index = 0;
    static uint8_t frame_len = 0;

    uint8_t ch;
    
    while(UART2GetChar(&ch) == 0)
    {
        switch(state)
        {
            case 0:
                if(ch == Board_Address)
                {
                    buf[0] = ch;
                    index = 1;
                    state = 1;
                }
                break;
            
            case 1:
                buf[index++] = ch;

                if(index >= 3)
                {
                    uint8_t data_len = buf[2];

                    //计算整帧长度
                    frame_len = 3 + data_len + 2;//测试完添加CRC+2

                    //长度保护
                    if(frame_len > sizeof(buf))
                    {
                        state = 0;
                        break;
                    }

                    state = 2;
                }
                break;

            case 2:
                buf[index++] = ch;

                if(index >= frame_len)
                {
                    //CRC校验
                    uint16_t crc_calc = my_crc(buf, frame_len - 2);

                    uint8_t crc_l = crc_calc & 0xFF;
                    uint8_t crc_h = (crc_calc >> 8) & 0xFF;

                    if(buf[frame_len - 2] != crc_l ||
                        buf[frame_len - 1] != crc_h)
                    {
                        state = 0;
                        break;
                    }

                    usr_msg.id = buf[0];
                    for(uint8_t i = 0; i < frame_len; i++)
                    {
                        usr_msg.rx_buf[i] = buf[i];
                    }

                    usr_msg.valid = 1;
                    
                    //CNT计算接收到的数据帧数
                    if(cnt <= 1000)
                    {
                      cnt++;
                    }else
                    {
                      cnt = 0;
                    }
                    
                    state = 0;
                }
                break;

            default:
                state = 0;
                break;
        }
    }
}

//将数据发送给中间件
void USR_Send_to_ZJJ(void)
{

    if(uart2_tx_busy) return;

    uint8_t send_len = 0;

    usr_zjj_buf[send_len++] = Board_Address;
    usr_zjj_buf[send_len++] = 0x00;
    usr_zjj_buf[send_len++] = 0x14;

    usr_zjj_buf[send_len++] = zjj_input_status_1;
    usr_zjj_buf[send_len++] = zjj_input_status_2;
    usr_zjj_buf[send_len++] = 0x00;
    usr_zjj_buf[send_len++] = 0x00;

    usr_zjj_buf[send_len++] = adc_send_buf[0];
    usr_zjj_buf[send_len++] = adc_send_buf[1];
    usr_zjj_buf[send_len++] = adc_send_buf[2];
    usr_zjj_buf[send_len++] = adc_send_buf[3];
    usr_zjj_buf[send_len++] = adc_send_buf[4];
    usr_zjj_buf[send_len++] = adc_send_buf[5];
    usr_zjj_buf[send_len++] = adc_send_buf[6];
    usr_zjj_buf[send_len++] = adc_send_buf[7];

    usr_zjj_buf[send_len++] = 0x00;
    usr_zjj_buf[send_len++] = HD7279_Keycode;

    usr_zjj_buf[send_len++] = 0x00;
    usr_zjj_buf[send_len++] = 0x00;
    usr_zjj_buf[send_len++] = 0x00;
    usr_zjj_buf[send_len++] = 0x00;
    usr_zjj_buf[send_len++] = 0x00;
    usr_zjj_buf[send_len++] = 0x00;

    uint16_t crc = my_crc(usr_zjj_buf, send_len);
    usr_zjj_buf[send_len++] = crc & 0xFF;
    usr_zjj_buf[send_len++] = (crc >> 8) & 0xFF;

    uart2_tx_busy = 1;
    HAL_UART_Transmit_DMA(&huart2, usr_zjj_buf, send_len);
}
