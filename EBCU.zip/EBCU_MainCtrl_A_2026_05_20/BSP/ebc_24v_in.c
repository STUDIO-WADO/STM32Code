#include "ebc_24v_in.h"

#define IN_NUM 4

typedef struct{
    GPIO_TypeDef *port;
    uint16_t pin;
}EBC_24V_INTypeDef;

static const EBC_24V_INTypeDef ebc_24v_in_table[IN_NUM] = {
    {IN_1_GPIO_Port, IN_1_Pin},
    {IN_2_GPIO_Port, IN_2_Pin},
    {IN_3_GPIO_Port, IN_3_Pin},
    {IN_4_GPIO_Port, IN_4_Pin}
};

uint8_t EBC_24V_IN_Read(uint8_t index)
{
    if (index == 0 || index > IN_NUM)
        return 0xFF;

    GPIO_PinState state = HAL_GPIO_ReadPin(
        ebc_24v_in_table[index - 1].port,
        ebc_24v_in_table[index - 1].pin
    );

    return (state == GPIO_PIN_RESET) ? 1 : 0;  // ON=1, OFF=0
}

uint8_t EBC_24V_IN_ReadAll(void)
{
    uint8_t value = 0;

    for (uint8_t i = 0; i < IN_NUM; i++)
    {
        uint8_t in = EBC_24V_IN_Read(i + 1);
        if (in == 1) value |= (1 << i);
    }

    return value;
}

uint8_t ebc_24v_in_value[IN_NUM];
uint8_t ebc_24v_in_all_value;

void ebc_24v_in_test(void)
{
    for (uint8_t i = 0; i < IN_NUM; i++)
    {
        ebc_24v_in_value[i] = EBC_24V_IN_Read(i + 1);
    }

    ebc_24v_in_all_value = EBC_24V_IN_ReadAll();
}

