#include "dip_switch.h"

typedef struct {
    GPIO_TypeDef *port;
    uint16_t pin;
} DIP_SW_GPIO_T;

static const DIP_SW_GPIO_T dip_sw_table[DIP_SW_NUM] = {
    {BM8_GPIO_Port, BM8_Pin},
    {BM7_GPIO_Port, BM7_Pin},
    {BM6_GPIO_Port, BM6_Pin},
    {BM5_GPIO_Port, BM5_Pin},
    {BM4_GPIO_Port, BM4_Pin},
    {BM3_GPIO_Port, BM3_Pin},
    {BM2_GPIO_Port, BM2_Pin},
    {BM1_GPIO_Port, BM1_Pin}
};

uint8_t DIP_Switch_Read(uint8_t index)
{
    if (index == 0 || index > DIP_SW_NUM)
        return 0xFF;

    GPIO_PinState state = HAL_GPIO_ReadPin(
        dip_sw_table[index - 1].port,
        dip_sw_table[index - 1].pin
    );

    return (state == GPIO_PIN_SET) ? 1 : 0;  // ON=1, OFF=0
}

// 读取所有位组成字节
uint8_t DIP_Switch_ReadAll(void)
{
    uint8_t value = 0;

    for (uint8_t i = 0; i < DIP_SW_NUM; i++)
    {
        uint8_t sw = DIP_Switch_Read(i + 1);
        if (sw == 1) value |= (1 << i);
    }

    return value;
}

uint8_t dip_switch_value[8];
uint8_t dip_switch_all_value;
uint8_t Board_Address;

void dip_switch_test(void)
{
    for (uint8_t i = 0; i < DIP_SW_NUM; i++)
    {
        dip_switch_value[i] = DIP_Switch_Read(i + 1);
    }

    dip_switch_all_value = DIP_Switch_ReadAll();
}

void dip_switch_Init(void)
{
    //获取当前6位拨码
    dip_switch_all_value = DIP_Switch_ReadAll();

    Board_Address = dip_switch_all_value&0X1F;
}
