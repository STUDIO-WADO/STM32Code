#ifndef __CRC16_H__
#define __CRC16_H__

uint16_t my_crc(unsigned char *buf, int len);

#endif
