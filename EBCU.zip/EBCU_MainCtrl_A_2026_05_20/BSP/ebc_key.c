#include "ebc_key.h"
#include "ebc_hd7279.h"
#include "ebc_pwmout.h"
#include "ebc_usr.h"

#define HD7279_KEY_RELEASED   0xFF

uint8_t HD7279_Keycode;             // 当前按键扫描值（HD7279 返回的键码）       
volatile uint8_t HD7279_Keyflag = 0;             // 按键触发标志（外部中断置位，主循环读取后清零）
uint8_t key_data_buf[32] = {0}; //按键数据缓存区
/**
 * @brief 外部中断回调函数
 * @param GPIO_Pin 被触发的引脚号
 * @note 当 HD7279 按键输出引脚触发中断时，将按键标志位置 1 GPIO_EXTI → Trigger = Falling edge
 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if(GPIO_Pin == HD7279_NKEY_Pin)
    {
        HD7279_Keyflag = 1;
    }
}

void Show_Key(void)
{
    // uint8_t key_read = 0;

    if(HD7279_Keyflag)
    {   //0X3F 0X37 0X2F 0X27
        HD7279_Keycode = HD7279_Read(CMD_READ); // 读取 HD7279 键码

        // if(key_read == HD7279_KEY_RELEASED)
        // {
        //     HD7279_Keycode = 0x00;
        // }else
        // {
        //     HD7279_Keycode = key_read;
        // }

        // //将键值发送到串口
        USR_Send_to_ZJJ();
        HD7279_Keyflag = 0; // 清除按键标志
    }
}
