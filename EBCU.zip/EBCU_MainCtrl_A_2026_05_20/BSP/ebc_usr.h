#ifndef __EBC_USR_H__
#define __EBC_USR_H__

#include "main.h"

typedef enum {
    EBC_PMOS_OUT_ID = 0,
    EBC_NONE_ID,
    EBC_DIGITAL_INPUT_ID,
    GROUP_1,
    GROUP_2,
    GROUP_3
} ebc_usr_type_t;

typedef struct {
    ebc_usr_type_t type;
    uint32_t id;
    uint8_t rx_buf[32];
    uint8_t tx_buf[32];
    uint8_t valid;
} ebc_usr_msg_t;

void Usr_Process(void);
void USR_Send_to_ZJJ(void);
#endif
