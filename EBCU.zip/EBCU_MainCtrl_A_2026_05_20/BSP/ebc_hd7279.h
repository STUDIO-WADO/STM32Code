#ifndef __EBC_HD7279_H__
#define __EBC_HD7279_H__

#include "main.h"

#define HD7279_NCS(x) do{x? \
                             HAL_GPIO_WritePin(HD7279_NCS_GPIO_Port, HD7279_NCS_Pin, GPIO_PIN_SET) : \
                             HAL_GPIO_WritePin(HD7279_NCS_GPIO_Port, HD7279_NCS_Pin, GPIO_PIN_RESET); \
                          }while(0)

#define HD7279_CLK(x) do{x? \
                             HAL_GPIO_WritePin(HD7279_CLK_GPIO_Port, HD7279_CLK_Pin, GPIO_PIN_SET) : \
                             HAL_GPIO_WritePin(HD7279_CLK_GPIO_Port, HD7279_CLK_Pin, GPIO_PIN_RESET); \
                          }while(0)

#define HD7279_DATA(x) do{x? \
                             HAL_GPIO_WritePin(HD7279_DATA_GPIO_Port, HD7279_DATA_Pin, GPIO_PIN_SET) : \
                             HAL_GPIO_WritePin(HD7279_DATA_GPIO_Port, HD7279_DATA_Pin, GPIO_PIN_RESET); \
                          }while(0)

#define HD7279_GET_DATA_PIN HAL_GPIO_ReadPin(HD7279_DATA_GPIO_Port, HD7279_DATA_Pin)

//****** HD7279A 指令******
#define CMD_RESET   0xA4        //复位清除
#define CMD_TEST    0xBF		//测试指令
#define DECODE0     0x80
#define DECODE1     0xC8        //译码显示
#define CMD_READ    0x15        //读键盘数据指令
													
//#define UNDECODE 0x90         //不译码
//#define UNDECODE 0x80         //0译码
#define UNDECODE    0xC8        //1译码	
													
#define RTL_CYCLE   0xa3
#define RTR_CYCLE   0xa2
#define RTL_UNCYL   0xa1
#define RTR_UNCYL   0xa0
#define ACTCTL      0x98		//消隐控制
#define SEGON       0xe0		//段点亮指令
#define SEGOFF      0xc0		//段关闭指令
#define BLINKCTL    0x88	    //闪烁控制

#define DATAIN   0
#define DATAOUT  !DATAIN

void HD7279_Init(void);
void HD7279_Send_Byte(uint8_t data);
uint8_t HD7279_Receive_Byte(void);
void HD7279_Write(uint8_t cmd, uint8_t data);
uint8_t HD7279_Read(uint8_t cmd);

void hd7279_test(void);

#endif
