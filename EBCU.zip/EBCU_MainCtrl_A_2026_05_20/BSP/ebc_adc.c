#include "ebc_adc.h"
#include "adc.h"
#include "ebc_usr.h"

#define FILTER_DEPTH     10     //求平均滤波深度
#define VREF 3.3f   // 参考电压
// #define DIV_RATIO   (2500.0f / 500.0f)  // = 5.0，分压比的倒数
#define DIV_RATIO   3.05f

uint8_t adc_send_buf[32];
uint16_t adc_filtered[ADC_CH_NUM];
float adc_voltage[ADC_CH_NUM];

extern volatile uint16_t adc_buf[ADC_CH_NUM];
static uint16_t filter_buf[ADC_CH_NUM][FILTER_DEPTH] = {0};
static uint8_t  filter_index[ADC_CH_NUM] = {0};

static uint16_t ADC_Filter(uint8_t ch, uint16_t input)
{
    uint32_t sum = 0;

    filter_buf[ch][filter_index[ch]] = input;
    filter_index[ch] = (filter_index[ch] + 1) % FILTER_DEPTH;

    for(int i = 0; i < FILTER_DEPTH; i++)
    {
        sum += filter_buf[ch][i];
    }

    return sum / FILTER_DEPTH;
}

// void ADC_Process(void)
// {
//     for(int i = 0; i < ADC_CH_NUM; i++)
//     {
//         // 1. 滤波
//         adc_filtered[i] = ADC_Filter(i, adc_buf[i]);

//         // 2. 转电压（单位：V）
//         adc_voltage[i] = (adc_filtered[i] * VREF / 4095.0f) * DIV_RATIO;
//     }
// }


void ADC_Process_ZJJ(void)
{
    uint8_t *p = adc_send_buf;

    for(uint8_t i = 0; i < ADC_CH_NUM; i++)
    {
        adc_filtered[i] = ADC_Filter(i, adc_buf[i]);

        *p++ = (uint8_t)(adc_filtered[i] >> 8);
        *p++ = (uint8_t)(adc_filtered[i]);
    }
    USR_Send_to_ZJJ();
    // USR_Send_to_ZJJ(adc_send_buf, p - adc_send_buf);
}

//void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
//{
//    if(hadc->Instance == ADC2)
//    {
//        ADC_Process_ZJJ();
//    }
//}
