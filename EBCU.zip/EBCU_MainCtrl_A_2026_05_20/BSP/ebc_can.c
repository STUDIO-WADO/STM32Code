#include "ebc_can.h"
#include "ebc_hd7279.h"
#include "can.h"
#include "ebc_timer.h"
#include "ebc_usr.h"
#include "usart.h"
#include "crc16.h"
#include <string.h>

CAN_TxHeaderTypeDef g_can1_txheader;    /* 发送参数句柄 */
CAN_RxHeaderTypeDef g_can1_rxheader;    /* 接收参数句柄 */

CAN_TxHeaderTypeDef g_can2_txheader;    /* 发送参数句柄 */
CAN_RxHeaderTypeDef g_can2_rxheader;    /* 接收参数句柄 */

RxMsg can1_rx_msg_buffer1;
RxMsg can1_rx_msg_buffer2;
RxMsg can2_msg;

TxMsg can1_tx_msg_buffer1;
TxMsg can1_tx_msg_buffer2;

uint8_t CAN1_RxBuf[8];//接收数据缓冲区
uint8_t CAN2_RxBuf[8];//接收数据缓冲区
uint8_t CAN1_NULL[8];

uint8_t Type_Board_1=0;
uint8_t Type_Board_2=0;
uint8_t Type_Board_3=0;
uint8_t Type_Board_4=0;

uint8_t zjj_input_status_1;
uint8_t zjj_input_status_2;

volatile uint8_t can1_rx_slave1_flag = 0;
volatile uint8_t can1_rx_slave2_flag = 0;
volatile uint8_t can2_rx_flag = 0;
volatile uint8_t uart2_tx_busy;

extern uint8_t dip_switch_all_value;
extern uint8_t CAN1_life;
extern ebc_usr_msg_t usr_msg;
extern uint8_t Board_Address;

//CAN中断回调函数
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
    if(hcan->Instance == CAN1)
    {
        //接收内部板卡数据
        if(HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &g_can1_rxheader, CAN1_RxBuf) == HAL_OK)
        {
            switch(g_can1_rxheader.StdId)
            {
                //第一张板卡的ID为0x21，第二张板卡的ID为0x31
                case 0x21:
                    can1_rx_slave1_flag = 1;    /* 设置接收标志 */
                    updata_msg_buffer(&can1_rx_msg_buffer1, &g_can1_rxheader, CAN1_RxBuf);
                    break;

                case 0x31:
                    can1_rx_slave2_flag = 1;    /* 设置接收标志 */
                    updata_msg_buffer(&can1_rx_msg_buffer2, &g_can1_rxheader, CAN1_RxBuf);
                    break;
                default:
                    break;
            }
        }
    }

    if(hcan->Instance == CAN2)
    {
        //接收外部的数据
        if(can2_receive_msg(g_can2_rxheader.StdId, CAN2_RxBuf))
        {
            can2_rx_flag = 1;    /* 设置接收标志 */
        }
    }
}

uint8_t CAN1_FilterConfig(void)
{
    CAN_FilterTypeDef can1FilterConfig;

    can1FilterConfig.FilterActivation = ENABLE;
    can1FilterConfig.FilterBank = 0;
    can1FilterConfig.FilterFIFOAssignment = CAN_FILTER_FIFO0;
    can1FilterConfig.FilterIdHigh = 0x0000;
    can1FilterConfig.FilterIdLow = 0x0000;
    can1FilterConfig.FilterMaskIdHigh = 0x0000;
    can1FilterConfig.FilterMaskIdLow = 0x0000;
    can1FilterConfig.FilterMode = CAN_FILTERMODE_IDMASK;
    can1FilterConfig.FilterScale = CAN_FILTERSCALE_32BIT;
    can1FilterConfig.SlaveStartFilterBank = 14;

    if(HAL_CAN_ConfigFilter(&hcan1, &can1FilterConfig) != HAL_OK)
    {
        /* Filter configuration Error */
        return 1;
    }

    if (HAL_CAN_Start(&hcan1) != HAL_OK)
    {
        return 2;
    }

    if (HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING) != HAL_OK) {
        Error_Handler();
    }
    
    return 0;
}

uint8_t CAN2_FilterConfig(void)
{
    CAN_FilterTypeDef can2FilterConfig;

    can2FilterConfig.FilterActivation = ENABLE;
    can2FilterConfig.FilterBank = 14;
    can2FilterConfig.FilterFIFOAssignment = CAN_FILTER_FIFO0;
    can2FilterConfig.FilterIdHigh = 0x0000;
    can2FilterConfig.FilterIdLow = 0x0000;
    can2FilterConfig.FilterMaskIdHigh = 0x0000;
    can2FilterConfig.FilterMaskIdLow = 0x0000;
    can2FilterConfig.FilterMode = CAN_FILTERMODE_IDMASK;
    can2FilterConfig.FilterScale = CAN_FILTERSCALE_32BIT;
    can2FilterConfig.SlaveStartFilterBank = 14;

    if(HAL_CAN_ConfigFilter(&hcan2, &can2FilterConfig) != HAL_OK)
    {
        /* Filter configuration Error */
        return 1;
    }

    if (HAL_CAN_Start(&hcan2) != HAL_OK)
    {
        return 2;
    }

    if (HAL_CAN_ActivateNotification(&hcan2, CAN_IT_RX_FIFO0_MSG_PENDING) != HAL_OK) {
        Error_Handler();
    }
    
    return 0;
}

uint8_t can1_send_msg(uint32_t id, uint8_t *msg, uint8_t len)
{
    uint16_t t = 0;
    uint32_t TxMailbox = CAN_TX_MAILBOX0;
    
    g_can1_txheader.StdId = id;         /* 标准标识符 */
    g_can1_txheader.ExtId = 0x00;         /* 扩展标识符(29位) */
    g_can1_txheader.IDE = CAN_ID_STD;   /* 使用标准帧 */
    g_can1_txheader.RTR = CAN_RTR_DATA; /* 数据帧 */
    g_can1_txheader.DLC = len;

    if (HAL_CAN_AddTxMessage(&hcan1, &g_can1_txheader, msg, &TxMailbox) != HAL_OK) /* 发送消息 */
    {
        return 1;
    }
    
    while (HAL_CAN_GetTxMailboxesFreeLevel(&hcan1) != 3)   /* 等待发送完成,所有邮箱为空 */
    {
        t++;
        
        if (t > 0xFFF)
        {
            HAL_CAN_AbortTxRequest(&hcan1, TxMailbox);     /* 超时，直接中止邮箱的发送请求 */
            return 1;
        }
    }
    return 0;
}

uint8_t can2_send_msg(uint32_t id, uint8_t *msg, uint8_t len)
{
    uint16_t t = 0;
    uint32_t TxMailbox = CAN_TX_MAILBOX0;
    
    g_can2_txheader.StdId = id;         /* 标准标识符 */
    g_can2_txheader.ExtId = 0x00;         /* 扩展标识符(29位) */
    g_can2_txheader.IDE = CAN_ID_STD;   /* 使用标准帧 */
    g_can2_txheader.RTR = CAN_RTR_DATA; /* 数据帧 */
    g_can2_txheader.DLC = len;

    if (HAL_CAN_AddTxMessage(&hcan2, &g_can2_txheader, msg, &TxMailbox) != HAL_OK) /* 发送消息 */
    {
        return 1;
    }
    
    while (HAL_CAN_GetTxMailboxesFreeLevel(&hcan2) != 3)   /* 等待发送完成,所有邮箱为空 */
    {
        t++;
        
        if (t > 0xFFF)
        {
            HAL_CAN_AbortTxRequest(&hcan2, TxMailbox);     /* 超时，直接中止邮箱的发送请求 */
            return 1;
        }
    }
    return 0;
}

uint8_t can1_receive_msg(uint32_t id, uint8_t *buf)
{
    if (HAL_CAN_GetRxFifoFillLevel(&hcan1, CAN_RX_FIFO0) == 0)     /* 没有接收到数据 */
    {
        return 0;
    }

    if (HAL_CAN_GetRxMessage(&hcan1, CAN_RX_FIFO0, &g_can1_rxheader, buf) != HAL_OK)  /* 读取数据 */
    {
        return 0;
    }
//    if (g_can1_rxheader.StdId!= id || g_can1_rxheader.IDE != CAN_ID_STD || g_can1_rxheader.RTR != CAN_RTR_DATA)       /* 接收到的ID不对 / 不是标准帧 / 不是数据帧 */
//    {
//        return 0;    
//    }
    return g_can1_rxheader.DLC;
}

uint8_t can2_receive_msg(uint32_t id, uint8_t *buf)
{
    if (HAL_CAN_GetRxFifoFillLevel(&hcan2, CAN_RX_FIFO0) == 0)     /* 没有接收到数据 */
    {
        return 0;
    }

    if (HAL_CAN_GetRxMessage(&hcan2, CAN_RX_FIFO0, &g_can2_rxheader, buf) != HAL_OK)  /* 读取数据 */
    {
        return 0;
    }
//    if (g_can2_rxheader.StdId!= id || g_can2_rxheader.IDE != CAN_ID_STD || g_can2_rxheader.RTR != CAN_RTR_DATA)       /* 接收到的ID不对 / 不是标准帧 / 不是数据帧 */
//    {
//        return 0;    
//    }
    return g_can2_rxheader.DLC;

}

//将CAN1接收的数据进行解析
void can1_forward(void)
{
    if(can1_rx_slave1_flag)
    {
        if(can1_rx_msg_buffer1.CAN_DATA[0][1] == ADDress_Board_1)
        {
            switch(can1_rx_msg_buffer1.CAN_DATA[0][2])
            {
                case 0x10:Type_Board_1=Type_Board_16PMOS_output;break;
                case 0x20:Type_Board_1=Type_Board_24DRY_output;break;
                case 0x30:Type_Board_1=Type_Board_16_input;break;
                default:Type_Board_1=0xFF;break;
            }
            //转发数据
            if(Type_Board_1 == Type_Board_16_input)
            {
                USR_Send_Input_To_ZJJ(
                    can1_rx_msg_buffer1.CAN_DATA[0][3],
                    can1_rx_msg_buffer1.CAN_DATA[0][4]
                );
            }
        }
        can1_rx_slave1_flag = 0;    /* 清除接收标志 */
    }
    if(can1_rx_slave2_flag)
    {
        if(can1_rx_msg_buffer2.CAN_DATA[0][1] == ADDress_Board_2)
        {
            switch(can1_rx_msg_buffer2.CAN_DATA[0][2])
            {
                case 0x10:Type_Board_2=Type_Board_16PMOS_output;break;
                case 0x20:Type_Board_2=Type_Board_24DRY_output;break;
                case 0x30:Type_Board_2=Type_Board_16_input;break;
                default:Type_Board_2=0xFF;break;
            }
            if(Type_Board_2 == Type_Board_16_input)
            {
                USR_Send_Input_To_ZJJ(
                    can1_rx_msg_buffer2.CAN_DATA[0][3],
                    can1_rx_msg_buffer2.CAN_DATA[0][4]
                );
            }
        }
        can1_rx_slave2_flag = 0;
    }
}

void USR_Send_Input_To_ZJJ(uint8_t input_status_1, uint8_t input_status_2)
{
    zjj_input_status_1 = input_status_1;
    zjj_input_status_2 = input_status_2;
    USR_Send_to_ZJJ();
}

void updata_msg_buffer(RxMsg *msg_buffer, CAN_RxHeaderTypeDef *rx_header, uint8_t *rx_data)
{
    msg_buffer->stdID = rx_header->StdId;
    msg_buffer->IDE = rx_header->IDE;
    msg_buffer->RTR = rx_header->RTR;
    msg_buffer->DLC = rx_header->DLC;

    uint8_t index = rx_data[0] - 1;

    if(index < 3)
    {
        memcpy(msg_buffer->CAN_DATA[index], rx_data, 8);
    }
}

//CAN2接收数码管的显示数据
void can_receive_digital_tube(void)
{
    if(can2_msg.stdID == 0x04 && can2_msg.CAN_DATA[0][0] == 0x04)
    {
        //数码管显示数据
        HD7279_Write(0x87, can2_msg.CAN_DATA[0][1]);
        HD7279_Write(0x86, can2_msg.CAN_DATA[0][2]);
        HD7279_Write(0x85, can2_msg.CAN_DATA[0][3]);
        HD7279_Write(0x84, can2_msg.CAN_DATA[0][4]);
    }
}

/*=====================================CAN1===================================== */
//读取板卡信息
void ebc_read_board_info(void)
{
    can1_send_msg(0x12, CAN1_NULL, 8);
    can1_send_msg(0x13, CAN1_NULL, 8);
}

//将USR-K7接收的数据让CAN1进行转发
void usr_forward_can1(void)
{
    if(usr_msg.valid)
    {
        //判断数据接收方
        if(usr_msg.rx_buf[1] == 0x00)
        {
            //判断接收方板卡类型
            if(Type_Board_1 == Type_Board_16PMOS_output)
            {
                can1_tx_msg_buffer1.CAN_SEND_BUF[0][0] = 0x01;
                can1_tx_msg_buffer1.CAN_SEND_BUF[0][3] = usr_msg.rx_buf[3];
                can1_tx_msg_buffer1.CAN_SEND_BUF[0][4] = usr_msg.rx_buf[4];

                can1_tx_msg_buffer1.CAN_SEND_BUF[1][0] = 0x02;
                can1_tx_msg_buffer1.CAN_SEND_BUF[2][0] = 0x03;
                can1_tx_msg_buffer1.CAN_SEND_BUF[2][7] = CAN1_life;

                //将第一张板卡的数据发送到CAN1
                for(uint8_t i = 0; i < 3; i++)
                {       
                    can1_send_msg(0x12, can1_tx_msg_buffer1.CAN_SEND_BUF[i], 8);
                    mdelay(10);
                }
            }
            if(Type_Board_1 == Type_Board_16_input)
            {
                can1_tx_msg_buffer1.CAN_SEND_BUF[0][0] = 0x01;
                can1_tx_msg_buffer1.CAN_SEND_BUF[1][0] = 0x02;
                can1_tx_msg_buffer1.CAN_SEND_BUF[2][0] = 0x03;
                can1_tx_msg_buffer1.CAN_SEND_BUF[2][7] = CAN1_life;

                //将第一张板卡的数据发送到CAN1
                for(uint8_t i = 0; i < 3; i++)
                {       
                    can1_send_msg(0x13, can1_tx_msg_buffer1.CAN_SEND_BUF[i], 8);
                    mdelay(10);
                }
            }
            //处理数码管
            if(usr_msg.rx_buf[2] == 0x14)
            {
                    ebc_led_hd7279(usr_msg.rx_buf);
            }
        }
        if(usr_msg.rx_buf[1] == ADDress_Board_2)
        {
            if(Type_Board_2 == Type_Board_16PMOS_output)
            {
                can1_tx_msg_buffer2.CAN_SEND_BUF[0][0] = 0x01;
                can1_tx_msg_buffer2.CAN_SEND_BUF[0][3] = usr_msg.rx_buf[3];
                can1_tx_msg_buffer2.CAN_SEND_BUF[0][4] = usr_msg.rx_buf[4];

                can1_tx_msg_buffer2.CAN_SEND_BUF[1][0] = 0x02;
                can1_tx_msg_buffer2.CAN_SEND_BUF[2][0] = 0x03;
                can1_tx_msg_buffer2.CAN_SEND_BUF[2][7] = CAN1_life;

                //将第二张板卡的数据发送到CAN1
                for(uint8_t i = 0; i < 3; i++)
                {       
                    can1_send_msg(0x13, can1_tx_msg_buffer2.CAN_SEND_BUF[i], 8);
                    mdelay(10);
                }
            }
            if(Type_Board_2 == Type_Board_16_input)
            {
                can1_tx_msg_buffer2.CAN_SEND_BUF[0][0] = 0x01;
                can1_tx_msg_buffer2.CAN_SEND_BUF[1][0] = 0x02;
                can1_tx_msg_buffer2.CAN_SEND_BUF[2][0] = 0x03;
                can1_tx_msg_buffer2.CAN_SEND_BUF[2][7] = CAN1_life;

                //将第二张板卡的数据发送到CAN1
                for(uint8_t i = 0; i < 3; i++)
                {       
                    can1_send_msg(0x13, can1_tx_msg_buffer2.CAN_SEND_BUF[i], 8);
                    mdelay(10);
                }
            }
        }
        
        usr_msg.valid = 0;    /* 清除数据有效标志 */
    }
}

//获取采集开关量的数据
void ebc_digital_input_forward_can1(void)
{
    can1_tx_msg_buffer2.CAN_SEND_BUF[0][0] = 0x01;
    can1_tx_msg_buffer2.CAN_SEND_BUF[1][0] = 0x02;
    can1_tx_msg_buffer2.CAN_SEND_BUF[2][0] = 0x03;
    can1_tx_msg_buffer2.CAN_SEND_BUF[2][7] = CAN1_life;

    //将第二张板卡的数据发送到CAN1
    for(uint8_t i = 0; i < 3; i++)
    {       
        can1_send_msg(0x13, can1_tx_msg_buffer2.CAN_SEND_BUF[i], 8);
        mdelay(10);
    }
}

/* =============================USR==================================== */
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart == &huart2)
    {
        uart2_tx_busy = 0;
    }
}

//将CAN1接收到的数据转发给USR-K7
uint8_t can1_forward_usr(uint8_t type_board, uint8_t *can1_rx_buf)
{
    //判断是否是在发送中
    if(uart2_tx_busy) return 1;

    static uint8_t buf[32];
    uint8_t index = 3;
    uint8_t len = 0;

    if(type_board == Type_Board_16_input)
    {
        buf[index++] = can1_rx_buf[3];
        buf[index++] = can1_rx_buf[4];
    }
    
    buf[0] = Board_Address;
    buf[1] = 0x00;
    buf[2] = index - 3;

    len = index + 2;

    buf[len - 2] = my_crc(buf, len - 2)&0xFF;
    buf[len - 1] = (my_crc(buf, len - 2) >> 8) & 0xFF;

    //发送数据
    if(index > 0)
    {
        uart2_tx_busy = 1;
        HAL_UART_Transmit_DMA(&huart2, buf, len);
    }
    return 0;
}

//USR接受更新数码管
void ebc_led_hd7279(uint8_t *led_buf)
{
    //数码管显示数据
    HD7279_Write(0x87, led_buf[8]);
    HD7279_Write(0x86, led_buf[10]);
    HD7279_Write(0x85, led_buf[12]);
    HD7279_Write(0x84, led_buf[14]);
}
