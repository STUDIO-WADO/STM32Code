#ifndef __DIP_SWITCH_H__
#define __DIP_SWITCH_H__

#include "gpio.h"

// 拨码开关数量
#define DIP_SW_NUM   8

// 函数声明
uint8_t DIP_Switch_Read(uint8_t index);
uint8_t DIP_Switch_ReadAll(void);

void dip_switch_test(void);
void dip_switch_Init(void);

#endif /* __DIP_SWITCH_H__ */
