#ifndef __EBC_24V_IN_H__
#define __EBC_24V_IN_H__

#include "main.h"

void ebc_24v_in_test(void);

#endif

